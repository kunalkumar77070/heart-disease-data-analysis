# Heart Disease Data Analysis

A beginner-friendly Exploratory Data Analysis (EDA) project using Python, Pandas, Matplotlib and Seaborn.

## Project Objective
Explore a heart disease dataset, clean the data, calculate basic statistics, inspect the target distribution and create useful visualizations.

## Dataset
Source: UCI Machine Learning Repository — Heart Disease dataset.

The original diagnosis field (`num`) uses:
- `0` = no presence of heart disease
- `1–4` = presence/severity of heart disease

For this educational project, it is converted to:
- `0` = no disease
- `1` = disease present

## Analysis Included
- Dataset shape and column names
- Data types
- Statistical summary
- Missing-value check
- Duplicate-row check
- Unique values per column
- Last 10 records
- Number of patients
- Mean, median and standard deviation of age and cholesterol
- Target class distribution
- Age histogram
- Cholesterol boxplot
- Resting blood-pressure boxplot
- Chest-pain count plot
- Correlation heatmap

## Technologies
- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Jupyter Notebook

## How to Run

### Google Colab
1. Open Google Colab.
2. Upload `heart_disease_analysis.ipynb`.
3. Run the cells from top to bottom.

### Local Jupyter
Install dependencies:

```bash
pip install -r requirements.txt
```

Then open the notebook:

```bash
jupyter notebook heart_disease_analysis.ipynb
```

## Project Structure

```text
heart-disease-data-analysis/
├── heart_disease_analysis.ipynb
├── analysis.py
├── README.md
├── requirements.txt
└── images/
```

## Disclaimer
This is an educational data-analysis project. It is not a medical diagnostic system.
